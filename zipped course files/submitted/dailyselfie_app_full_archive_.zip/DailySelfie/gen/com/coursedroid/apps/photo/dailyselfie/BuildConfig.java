/** Automatically generated file. DO NOT MODIFY */
package com.coursedroid.apps.photo.dailyselfie;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}